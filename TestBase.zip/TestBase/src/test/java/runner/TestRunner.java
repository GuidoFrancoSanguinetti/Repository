package runner;

public class TestRunner {
    // No need to write any code. The @Cucumber annotation will do the work.
}