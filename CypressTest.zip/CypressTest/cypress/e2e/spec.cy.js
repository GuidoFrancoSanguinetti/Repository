describe('Base Test', () => {
  it('passes', () => {
    cy.visit('https://www.demoblaze.com')
  })
})